module vedic8x8 (
    input  [7:0] a,
    input  [7:0] b,
    output [15:0] p
);
    wire [7:0] p0, p1, p2, p3;
    wire [15:0] t1, t2, t3, s1, s2;
    wire cout1, cout2;

    wire [3:0] a0 = a[3:0];
    wire [3:0] a1 = a[7:4];
    wire [3:0] b0 = b[3:0];
    wire [3:0] b1 = b[7:4];

    vedic4x4 m1 (.a(a0), .b(b0), .p(p0));
    vedic4x4 m2 (.a(a1), .b(b0), .p(p1));
    vedic4x4 m3 (.a(a0), .b(b1), .p(p2));
    vedic4x4 m4 (.a(a1), .b(b1), .p(p3));

    assign t1 = {8'b0, p0};
    assign t2 = ({p1, 4'b0} + {p2, 4'b0});
    assign t3 = {p3, 8'b0};

    carry_select_adder #(16) add1 (.a(t1), .b(t2), .cin(1'b0), .sum(s1), .cout(cout1));
    carry_select_adder #(16) add2 (.a(s1), .b(t3), .cin(1'b0), .sum(s2), .cout(cout2));

    assign p = s2;
endmodule

