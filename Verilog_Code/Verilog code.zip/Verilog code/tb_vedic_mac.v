`timescale 1ns/1ps

module tb_vedic_mac;

    reg clk;
    reg rst;
    reg acc_en;
    reg acc_clr;
    reg signed [15:0] a;
    reg signed [15:0] b;

    wire signed [31:0] product;
    wire signed [31:0] accumulator;

    top_vedic_mac_example dut (
        .clk(clk),
        .rst(rst),
        .acc_en(acc_en),
        .acc_clr(acc_clr),
        .a(a),
        .b(b),
        .product(product),
        .accumulator(accumulator)
    );

    // Clock 10ns period
    initial clk = 0;
    always #10 clk = ~clk;

    // Print both Decimal & Binary
    initial begin
        $display("=======================================================================================================================================================");
        $display(" Time | clk | rst | acc_en | a(dec) | a(bin)              | b(dec) | b(bin)              | product(dec) | product(bin)                     | acc(dec) | acc(bin)");
        $display("=======================================================================================================================================================");
        $monitor("%5t |  %b  |  %b  |   %b   | %6d | %16b | %6d | %16b | %10d | %32b | %6d | %32b",
                 $time, clk, rst, acc_en, a, a, b, b, product, product, accumulator, accumulator);
    end

    initial begin
        rst = 1;
        acc_en = 0;
        acc_clr = 0;
        a = 0;
        b = 0;
        #10 rst = 0;
        acc_en = 1;

        // Test cases
        a = 16'd25; b = 16'd15; #20;   // +25 � +15 = 375
        a = 16'd12; b = -16'd8; #20;   // +12 � -8 = -96
        a = -16'd20; b = 16'd10; #20;  // -20 � +10 = -200
        a = -16'd5;  b = -16'd4; #20;  // -5 � -4 = +20
        a = 16'd10;  b = 16'd10; #20;  // +10 � +10 = +100
        a = 16'd5;   b = 16'd5;  #20;  // +5 � +5 = +25
        a = -16'd2;  b = 16'd6;  #20;  // -2 � +6 = -12

        // Clear Accumulator
        acc_clr = 1; #10; acc_clr = 0; #10;

        // Random checks
        repeat (4) begin
            a = $random;
            b = $random;
            #20;
        end

        $display("\n==== Simulation Complete ====");
        #20 $stop;
    end

endmodule

