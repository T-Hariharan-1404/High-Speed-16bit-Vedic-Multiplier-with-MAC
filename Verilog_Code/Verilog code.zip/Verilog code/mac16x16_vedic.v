// =======================================================
// 16-bit Signed Vedic MAC Unit (Clock-Safe & Pipelined)
// =======================================================

module mac16x16_vedic (
    input  wire              clk,        // Clock signal
    input  wire              rst,        // Asynchronous reset (active high)
    input  wire              acc_en,     // Accumulate enable
    input  wire              acc_clr,    // Clear accumulator
    input  wire signed [15:0] a,         // Signed input A
    input  wire signed [15:0] b,         // Signed input B
    output reg  signed [31:0] acc_out,   // Accumulator output
    output wire signed [31:0] last_prod  // Last product output (for debugging)
);

    // -----------------------------
    // Internal signals
    // -----------------------------
    wire signed [31:0] mul_out;          // Multiplier output
    reg  signed [31:0] product_reg;      // Registered product (1-cycle latency)

    // -----------------------------
    // Instantiate 16x16 signed Vedic multiplier
    // -----------------------------
    vedic16x16_signed mul_inst (
        .a(a),
        .b(b),
        .p(mul_out)
    );

    // -----------------------------
    // Stage 1: Register product
    // -----------------------------
    always @(posedge clk or posedge rst) begin
        if (rst)
            product_reg <= 32'sd0;
        else
            product_reg <= mul_out;   // Capture multiplier output every clock
    end

    assign last_prod = product_reg;   // Output registered product (for waveform view)

    // -----------------------------
    // Stage 2: Accumulate (signed)
    // -----------------------------
    always @(posedge clk or posedge rst) begin
        if (rst)
            acc_out <= 32'sd0;
        else if (acc_clr)
            acc_out <= 32'sd0;
        else if (acc_en)
            acc_out <= $signed(acc_out) + $signed(product_reg); // Signed accumulation
    end

endmodule


