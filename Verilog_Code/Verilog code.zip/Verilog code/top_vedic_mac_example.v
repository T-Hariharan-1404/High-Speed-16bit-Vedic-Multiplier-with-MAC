module top_vedic_mac_example (
    input  wire clk,
    input  wire rst,
    input  wire acc_en,
    input  wire acc_clr,
    input  wire signed [15:0] a,
    input  wire signed [15:0] b,
    output wire signed [31:0] product,
    output wire signed [31:0] accumulator
);
    vedic16x16_signed mul0 (.a(a), .b(b), .p(product));
    mac16x16_vedic mac0 (
        .clk(clk),
        .rst(rst),
        .acc_en(acc_en),
        .acc_clr(acc_clr),
        .a(a),
        .b(b),
        .acc_out(accumulator),
        .last_prod()
    );
endmodule

