module carry_select_adder #(parameter N = 16)(
    input  signed [N-1:0] a,
    input  signed [N-1:0] b,
    input          cin,
    output signed [N-1:0] sum,
    output         cout
);
    localparam HALF = N/2;

    wire c_low;
    wire signed [HALF-1:0] sum_low;
    wire signed [HALF-1:0] sum_high0, sum_high1;
    wire c_high0, c_high1;

    // Lower half ripple adder
    assign {c_low, sum_low} = a[HALF-1:0] + b[HALF-1:0] + cin;

    // Upper half precompute
    assign {c_high0, sum_high0} = a[N-1:HALF] + b[N-1:HALF] + 1'b0;
    assign {c_high1, sum_high1} = a[N-1:HALF] + b[N-1:HALF] + 1'b1;

    // Select correct upper result
    assign {cout, sum[N-1:HALF]} = (c_low) ? {c_high1, sum_high1} : {c_high0, sum_high0};
    assign sum[HALF-1:0] = sum_low;

endmodule

