//=======================================================
//  DE2-115 : 16x16 Signed Vedic Multiplier + MAC
//  Mode Control via Switch:
//   SW[1:0] = 01 -> Multiplication Mode
//   SW[1:0] = 10 -> MAC (Multiply?Accumulate)
//=======================================================

module vedic_mac_fpga_top(
    input [15:0] SW,          // Lower 16 switches: Input A
    input [31:16] SW_B,       // Upper 16 switches: Input B
    input [1:0] MODE,         // Mode selection switches
    input CLK,                // Clock (KEY[0])
    input RST,                // Reset (KEY[1])
    output [6:0] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5, HEX6, HEX7
);

    wire [15:0] a = SW;
    wire [15:0] b = SW_B;
    wire [31:0] mult_out;
    reg [31:0] mac_reg;

    // Instantiate 16x16 signed vedic multiplier
    vedic16x16_signed uut(
        .a(a),
        .b(b),
        .c(mult_out)
    );

    // Mode Control Logic
    always @(posedge CLK or posedge RST) begin
        if (RST)
            mac_reg <= 32'd0;
        else begin
            case (MODE)
                2'b01: mac_reg <= mult_out;            // Multiplication mode
                2'b10: mac_reg <= mac_reg + mult_out;  // MAC mode
                default: mac_reg <= mac_reg;           // Hold
            endcase
        end
    end

    // Output result
    wire [31:0] result = mac_reg;

    // Display result on HEX0?HEX7
    hex7seg h0(result[3:0], HEX0);
    hex7seg h1(result[7:4], HEX1);
    hex7seg h2(result[11:8], HEX2);
    hex7seg h3(result[15:12], HEX3);
    hex7seg h4(result[19:16], HEX4);
    hex7seg h5(result[23:20], HEX5);
    hex7seg h6(result[27:24], HEX6);
    hex7seg h7(result[31:28], HEX7);

endmodule

//=======================================================
//  HEX Display Decoder
//=======================================================
module hex7seg(input [3:0] data, output reg [6:0] seg);
    always @(*) begin
        case(data)
            4'h0: seg = 7'b1000000;
            4'h1: seg = 7'b1111001;
            4'h2: seg = 7'b0100100;
            4'h3: seg = 7'b0110000;
            4'h4: seg = 7'b0011001;
            4'h5: seg = 7'b0010010;
            4'h6: seg = 7'b0000010;
            4'h7: seg = 7'b1111000;
            4'h8: seg = 7'b0000000;
            4'h9: seg = 7'b0010000;
            4'hA: seg = 7'b0001000;
            4'hB: seg = 7'b0000011;
            4'hC: seg = 7'b1000110;
            4'hD: seg = 7'b0100001;
            4'hE: seg = 7'b0000110;
            4'hF: seg = 7'b0001110;
            default: seg = 7'b1111111;
        endcase
    end
endmodule

