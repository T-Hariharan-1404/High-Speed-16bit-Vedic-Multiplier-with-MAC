module vedic4x4 (
    input  [3:0] a,
    input  [3:0] b,
    output [7:0] p
);
    wire [7:0] temp[3:0];
    wire [7:0] sum1, sum2;
    wire cout1, cout2, cout3;

    assign temp[0] = a[0] ? {4'b0, b} : 8'b0;
    assign temp[1] = a[1] ? {3'b0, b, 1'b0} : 8'b0;
    assign temp[2] = a[2] ? {2'b0, b, 2'b0} : 8'b0;
    assign temp[3] = a[3] ? {1'b0, b, 3'b0} : 8'b0;

    carry_select_adder #(8) add1 (.a(temp[0]), .b(temp[1]), .cin(1'b0), .sum(sum1), .cout(cout1));
    carry_select_adder #(8) add2 (.a(temp[2]), .b(temp[3]), .cin(1'b0), .sum(sum2), .cout(cout2));
    carry_select_adder #(8) add3 (.a(sum1), .b(sum2), .cin(1'b0), .sum(p), .cout(cout3));
endmodule

