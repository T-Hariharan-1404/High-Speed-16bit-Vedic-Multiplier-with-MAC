module vedic16x16_signed (
    input  signed [15:0] a,
    input  signed [15:0] b,
    output signed [31:0] p
);
    // Determine the sign of the result
    wire sign_out = a[15] ^ b[15];

    // Get magnitudes
    wire [15:0] a_abs = a[15] ? (~a + 1'b1) : a;
    wire [15:0] b_abs = b[15] ? (~b + 1'b1) : b;

    // Split into 8-bit halves
    wire [7:0] a0 = a_abs[7:0];
    wire [7:0] a1 = a_abs[15:8];
    wire [7:0] b0 = b_abs[7:0];
    wire [7:0] b1 = b_abs[15:8];

    // Partial products
    wire [15:0] p0, p1, p2, p3;
    wire [31:0] t1, t2, t3, s1, s2;
    wire cout1, cout2;

    vedic8x8 m1 (.a(a0), .b(b0), .p(p0));
    vedic8x8 m2 (.a(a1), .b(b0), .p(p1));
    vedic8x8 m3 (.a(a0), .b(b1), .p(p2));
    vedic8x8 m4 (.a(a1), .b(b1), .p(p3));

    assign t1 = {16'b0, p0};
    assign t2 = ({p1, 8'b0} + {p2, 8'b0});
    assign t3 = {p3, 16'b0};

    carry_select_adder #(32) add1 (.a(t1), .b(t2), .cin(1'b0), .sum(s1), .cout(cout1));
    carry_select_adder #(32) add2 (.a(s1), .b(t3), .cin(1'b0), .sum(s2), .cout(cout2));

    // Apply sign correction
    assign p = sign_out ? -$signed(s2) : $signed(s2);
endmodule

